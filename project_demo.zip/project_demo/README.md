## Project 2

This project makes use of the MSP430 available functions to interpret a childrens toy allowing both buzzer sounds and blinking lights. The 4 buttons are simulated to represent the notes G, D, A, E similar to a violin, added is the ability to combine notes with the button next to it for a different sound. Leds are to be changed based on when a button is pressed by changing the state it currently is in.

Frequencies are from website: https://pages.mtu.edu/~suits/notefreqs.html

Lab contains code from demos provided by Computer Architecture lab:
Buzzer, led, switches, makefile, and main.